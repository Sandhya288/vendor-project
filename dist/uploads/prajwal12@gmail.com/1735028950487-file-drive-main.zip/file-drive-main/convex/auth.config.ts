export default {
  providers: [
    {
      domain: "https://poetic-salmon-66.clerk.accounts.dev",
      applicationID: "convex",
    },
  ],
};
