import { FileBrowser } from "../_components/file-browser";

export default function FilesPage() {
  return (
    <div>
      <FileBrowser title="Your Files" />
    </div>
  );
}
